clc
clear;
tic

format('long')
addpath('..')

a = readtable('./Configuration/sigma.txt');
sigma_array = table2array(a);
[var, value] = readvars('./Configuration/config.xlsx');

for i = 1:height(var)
    assignin('base', string(var(i)), value(i)) %assigin assigns var(i) to value(i) by defining var(i) in the workspace
end
n_min = ceil(1/2 * log2(L * beta * d * (rho -mu)/(2*epsilon)));

E_MAC_MAX = A *(n_max/n_max)^alpha;
E_back = E_MAC_MAX*2*N_c + 2*2*E_MAC_MAX*O_c * 2*E_MAC_MAX*d + 2*E_MAC_MAX*N_c*sqrt(1/p) + A_d*E_MAC_MAX * max(d *32 + 2*O_c*32 - SRAM, 0);

%%%%%%%%%%%%%%%%%%%%%%%
%Optimize the sampling probability 
samp_prob = Optimize_sampling_prob(sigma_array); %Sampling prob for each device
variance_term = sum(samp_prob.^2 .* sigma_array.^2);
power_d_SNR_list = Get_comm_parameter(avg_counter, N, square_length, power, bandwidth, Noise, d, path_loss_exponent);

%%%%%% NBI method%%%%%

[Num_glo_iterations, Energy_consumption, Pareto_points, E_min, T_min, E_uto, T_uto] = ...
    NBI_function(N, variance_term, samp_prob, SGD_bound, power_d_SNR_list, ...
    epsilon, L, mu, beta, gamma, d,  rho, Noniid, N_c, NBI_resolution, PENALTY_INCREASE, threshold, p, A, A_d, alpha, O_c, x_dim, SRAM, ...
    E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);


[Energy_consumption_ex, Num_glo_iterations_ex] = Exaustive_search(N,samp_prob, variance_term, SGD_bound, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, d, rho, Noniid, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back,E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);

scatter(Energy_consumption_ex, Num_glo_iterations_ex, 5, 'b');
ylim([150 350])
xlim([0 100])
hold on;
plot(Energy_consumption, Num_glo_iterations, 'k', 'Linewidth', 4)


xlabel('Energy consumption [J]', 'Interpreter','latex')
ylabel('Number of communication rounds', 'Interpreter','latex')
legend('Exaustive search', 'Proposed Algorithm', 'Interpreter','latex')
grid on
set(gca, 'fontsize', 14)
box on


toc

