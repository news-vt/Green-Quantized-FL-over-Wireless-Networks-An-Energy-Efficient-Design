clc
clear;
tic

format('long')
addpath('..')
a = readtable('../Configuration/sigma.txt');
sigma_array = table2array(a);
[var, value] = readvars('../Configuration/config.xlsx');

for i = 1:height(var)
    assignin('base', string(var(i)), value(i)) %assigin assigns var(i) to value(i) by defining var(i) in the workspace
end

E_MAC_MAX = A *(n_max/n_max)^alpha;
E_back = E_MAC_MAX*2*N_c + 2*2*E_MAC_MAX*O_c * 2*E_MAC_MAX*d + 2*E_MAC_MAX*N_c*sqrt(1/p);

%%%%%%%%%%%%%%%%%%%%%%%
%Optimize the sampling probability
samp_prob = Optimize_sampling_prob(sigma_array); %Sampling prob for each device
variance_term = sum(samp_prob.^2 .* sigma_array.^2);
power_d_SNR_list = Get_comm_parameter(avg_counter, N, square_length, power, bandwidth, Noise, d, path_loss_exponent);

epsilon_bound_list = logspace(-1, -3, 10);

E_min_sol_list = zeros(length(epsilon_bound_list), 4);
T_min_sol_list = zeros(length(epsilon_bound_list), 4);

NBS_list = zeros(length(epsilon_bound_list), 4);
SU_list = zeros(length(epsilon_bound_list), 4);

NBS_performance_list = zeros(length(epsilon_bound_list), 2);
SU_preformance_list = zeros(length(epsilon_bound_list), 2);

%%%%%%%%%%%%%%%%%
%Optimization Setting
%%%%%%%%%%%%%%%%5

NBI_resolution = 400;
PENALTY_INCREASE = 5;
threshold = 1; 

%%%%%% NBI method%%%%%

epsilon_count = 1;
for epsilon = epsilon_bound_list
    n_min = ceil(1/2 * log2(L * beta * d * (rho -mu)/(2*epsilon)));
    [Num_glo_iterations, Energy_consumption, Pareto_points, E_min, T_min, E_uto, T_uto] = ...
        NBI_function(N, variance_term, samp_prob, SGD_bound, power_d_SNR_list, ...
        epsilon, L, mu, beta, gamma, d,  rho, Noniid, N_c, NBI_resolution, PENALTY_INCREASE, threshold, p, A, A_d, alpha, O_c, x_dim, SRAM, ...
        E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);
    
    %%%%%% First, obtain the disagreement point %%%%%%
    Psi_one = @(x) d*(rho - mu)/2^(2*x(4)) + 0*x(1) + 0*x(2) + 0*x(3);
    Psi_two = @(x) variance_term + 4*(x(1)-1)^2 * SGD_bound^2 + 4*d*x(1)*SGD_bound^2/(x(2)*2^(2*x(3)))...
        + 4* x(1)^2 * SGD_bound^2/x(2) + 4*L*Noniid + 0*x(4);
    T_ = @(x) beta^2 * Psi_two(x)/( x(1) * (beta*mu -1) * (2*epsilon/L - beta*Psi_one(x)/(beta*mu -1))) - gamma/x(1);
    
    E_MAC = @(x) A * (x(4)/n_max)^alpha +x(1) *0 + x(2) *0 +x(3) *0;
    E_M = @(x) 2*E_MAC(x);
    E_D = @(x) A_d * E_MAC(x);
    E_comp = @(x) E_MAC(x)*N_c + 2 * O_c *E_MAC_MAX;
    E_weight = @(x) E_M(x) * d + E_MAC(x) *N_c *sqrt(x(4)/(p*n_max));
    E_act = @(x) 2 * E_M(x) * O_c + E_MAC(x) * N_c * sqrt(x(4)/(p*n_max));
    E_DRAM = @(x) A_d * E_MAC_MAX *x_dim + 2 * E_D(x) * max(d*x(4) + 2*O_c *x(4) -SRAM, 0);
    E_inf = @(x) E_comp(x) + E_weight(x) + E_act(x) + E_DRAM(x);
    E_training = @(x) (E_inf(x) + E_back) * minibatch;
    
    E_comm = @(x) sum(samp_prob.* power_d_SNR_list) *x(3) + 0*x(1) + 0*x(2) + 0*x(4);
    
    Energy_consumption_per_round = @(x) x(1) * x(2) * E_training(x) + E_comm(x) * x(2);
    
    E_ = @(x) T_(x)* Energy_consumption_per_round(x);
    
    %%%%%%NBI%%%%%%%%%
    Disagree = [I_max, 1,   1, n_min];
    Disagree_point_T = T_(Disagree);
    Disagree_point_E = E_(Disagree);
    
    NASH_INPUT = Energy_consumption;
    Nash_output = zeros(1, length(NASH_INPUT));
    [NBS_energy, NBS_time, tangential, CONSTANT, NBS_INPUT, NBS_OUTPUT]  = bisection(NASH_INPUT,CONSTANT_small, CONSTANT_big, Num_glo_iterations, Disagree_point_T, Disagree_point_E, threshold_distant);
    
    SU_CONSTANT_small = 0;
    SU_CONSTANT_big = 50000;
    [SU_energy, SU_time, SU_tangential, SU_CONSTANT]  = SU_bisection(NASH_INPUT,SU_CONSTANT_small, SU_CONSTANT_big, Num_glo_iterations, threshold_distant);
    
    SU_para = @(x) -x + SU_CONSTANT;
    for j = 1:length(NASH_INPUT)
        SU_Nash_output(j) = SU_para(NASH_INPUT(j));
    end
    
    NBS_solution = Pareto_points(tangential,:);
    SU_solution = Pareto_points(SU_tangential,:);
    
    E_min_sol_list(epsilon_count, :) = E_min;
    T_min_sol_list(epsilon_count, :) = T_min;
    NBS_list(epsilon_count, :) = NBS_solution;
    SU_list(epsilon_count, :) = SU_solution;
    NBS_performance_list(epsilon_count, :) = [NBS_energy, NBS_time];
    SU_preformance_list(epsilon_count, :) = [SU_energy, SU_time];
    epsilon_count = epsilon_count + 1;
end

E_min_sol_list = round(E_min_sol_list);
T_min_sol_list = round(T_min_sol_list);
NBS_list = round(NBS_list);
SU_list = round(SU_list);
T_min_sol_list(:, 3) = 32;
T_min_sol_list(:, 4) = 32;

plot(epsilon_bound_list, NBS_list(:,1), '-sr')
hold on;
plot(epsilon_bound_list, SU_list(:,1), '-og')
hold on;
plot(epsilon_bound_list, E_min_sol_list(:, 1), '-*b')
hold on;
plot(epsilon_bound_list, T_min_sol_list(:, 1), '-^k')
xlim([0 0.1])
xlabel('accuracy constraint \epsilon')
ylabel('The number of local iterations I')
legend('NBS', 'SU', '$E_{\mathrm{min}}$', '$T_{\mathrm{min}}$', 'Interpreter','latex')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;

%yyaxis right
figure(2)
plot(epsilon_bound_list, NBS_list(:,2), '-sr')
hold on;
plot(epsilon_bound_list, SU_list(:,2), '-og')
hold on;
plot(epsilon_bound_list, E_min_sol_list(:, 2), '-*b')
hold on;
plot(epsilon_bound_list, T_min_sol_list(:, 2), '-^k')
xlim([0 0.1])
xlabel('accuracy constraint \epsilon')
legend('NBS', 'SU', '$E_{\mathrm{min}}$', '$T_{\mathrm{min}}$', 'Interpreter','latex')
ylabel('The number of selected devices K')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;

figure(3)
plot(epsilon_bound_list, NBS_list(:,3), '-sr')
hold on;
plot(epsilon_bound_list, SU_list(:,3), '-og')
hold on;
plot(epsilon_bound_list, E_min_sol_list(:, 3), '-*b')
hold on;
plot(epsilon_bound_list, T_min_sol_list(:, 3), '-^k')
xlim([0 0.1])
xlabel('accuracy constraint \epsilon')
legend('NBS', 'SU', '$E_{\mathrm{min}}$', '$T_{\mathrm{min}}$', 'Interpreter','latex')
ylabel('Precision level for the transmission m')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;

figure(4)
plot(epsilon_bound_list, NBS_list(:,4), '-sr')
hold on;
plot(epsilon_bound_list, SU_list(:,4), '-og')
hold on;
plot(epsilon_bound_list, E_min_sol_list(:, 4), '-*b')
hold on;
plot(epsilon_bound_list, T_min_sol_list(:, 4), '-^k')
xlim([0 0.1])
ylim([15, 32])
xlabel('target accuracy $\epsilon$', 'Interpreter', 'latex')
legend('NBS', 'SUM', '$E_{\mathrm{min}}$', '$T_{\mathrm{min}}$', 'Interpreter','latex')
ylabel('Precision level $n$', 'Interpreter', 'latex')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;

figure(5)
plot(epsilon_bound_list, NBS_performance_list(:, 1), '-sk' )
xlabel('accuracy constraint \epsilon')
ylabel('Energy consumption [J]')
hold on
xlim([0 0.1])
yyaxis right
plot(epsilon_bound_list, NBS_performance_list(:,2), '-or')
ylabel('# of communication rounds')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;
title('Nash bargaining solution')
legend('Energy' , '# of communication rounds', 'Interpreter','latex')

figure(6)
plot(epsilon_bound_list, SU_preformance_list(:, 1), '-sk' )
xlabel('accuracy constraint \epsilon')
ylabel('Energy consumption [J]')
hold on
yyaxis right
xlim([0 0.1])
plot(epsilon_bound_list, SU_preformance_list(:,2), '-or')
ylabel('Communication rounds')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
title('Sum minimizing solution')
grid on;
legend('Energy' , '# of communication rounds', 'Interpreter','latex')


figure(7)
plot(epsilon_bound_list, NBS_performance_list(:, 1), '-sk')
hold on;
plot(epsilon_bound_list, SU_preformance_list(:, 1), '-*k' )
xlabel('target accuracy $\epsilon$', 'Interpreter','latex')
ylabel('Energy consumption [J]', 'Interpreter','latex')
set(gca, 'fontsize', 17)
hold on

yyaxis right
xlim([0 0.1])
plot(epsilon_bound_list, NBS_performance_list(:,2), '-sr')
hold on
plot(epsilon_bound_list, SU_preformance_list(:,2), '-*r')
ylabel('Communication rounds', 'Interpreter','latex')
set(gca, 'XScale', 'log')
set(gca, 'fontsize', 17)
grid on;
legend('NBS' , 'SUM', 'Interpreter','latex')
ax = gca;
ax.YAxis(2).Color = 'r';
toc

