function [I, K, t_precision, precision, I_T_opt] = Energy_opt_function ...
    (N,SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch)

%initial values
square_sum = 10;
stopping_criterion =0.1;
K = 1;
I = 2;
precision = 20;
t_precision = 9;
call = 1;

while square_sum > stopping_criterion
    %%%%%%% Define energy-related terms%%%%%
    
    %%%%%%% I optimal %%%%%%%%%%
    [I_optimal] = I_search(K, precision, t_precision, SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);

    
    [m_optimal] = m_search(K, precision, I_optimal, SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);

    if imag(m_optimal) ~= 0
        m_optimal = 1;
    end
    
    [E_n_min, n_optimal, E_n_list] =  n_search(K, m_optimal, I_optimal, ...
    samp_prob, power_d_SNR_list, epsilon, L, mu, beta, gamma, d, rho, Noniid, variance_term, ...
    SGD_bound, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back,E_MAC_MAX, n_min, n_max, minibatch);
    call = call + 1;
    n_optimal = round(n_optimal);
    if n_optimal < n_min
        n_optimal = n_min;
    
    square_sum = sqrt((t_precision-m_optimal)^2 + (I-I_optimal)^2 + (precision - n_optimal)^2);
    
    I = I_optimal;
    t_precision = m_optimal;
    precision = n_optimal;
    
    if I == 0 || t_precision == 0 || precision == 0 %% Prevents a weird  value
        I = randi([1, I_max], 1);
        precision = randi([1, n_max], 1);
        t_precision = randi([1, m_max], 1);
    end
end



%%%% Minimizing T together %%%%%
Psi_one = d*(rho - mu)/2^(2*n_max);
I_T_opt =  sqrt( ( variance_term + 4 *SGD_bound^2 + 4*L*Noniid - gamma*(beta*mu-1)...
    *(2*epsilon/L - beta*Psi_one/(beta*mu-1))/beta^2)/(4*SGD_bound^2 + 4*SGD_bound^2/N) );
end
