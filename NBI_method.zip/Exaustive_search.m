function [Energy_consumption, Number_of_comm] = Exaustive_search...
    (N,samp_prob, variance_term, SGD_bound, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, d, rho, Noniid, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch)

total_iteration = N * I_max * m_max * (n_max-n_min);
Energy_consumption = zeros(total_iteration, 1);
Number_of_comm = zeros(total_iteration, 1);


j = 1;
for K = 1:0.5:N
    for I = 1:0.2:I_max
        for t_precision = 1:0.5:m_max
            for precision = n_min:0.5:n_max
                Psi_one = d*(rho - mu)/2^(2*precision);
                Psi_two = variance_term + 4*(I-1)^2*SGD_bound^2 + 4*d*I*SGD_bound^2/(K*2^(2*t_precision))...
                    + 4*I^2*SGD_bound^2/K + 4*L*Noniid;

                T = beta^2 * Psi_two/(I*(beta*mu-1) * (2*epsilon/L - beta*Psi_one/(beta*mu-1))) - gamma/I;
                Number_of_comm(j) = T;
                                
                E_MAC = A * (precision/n_max)^alpha;
                E_M = 2*E_MAC;
                E_D = A_d * E_MAC;
                E_comp = E_MAC*N_c + 2 * O_c *E_MAC_MAX;
                E_weight = E_M * d + E_MAC *N_c *sqrt(precision/(p*n_max));
                E_act = 2 * E_M * O_c + E_MAC * N_c * sqrt(precision/(p*n_max));
                E_DRAM = A_d * E_MAC_MAX *x_dim + 2 * E_D * max(d*precision + 2*O_c *precision -SRAM, 0);
                E_inf = E_comp + E_weight + E_act + E_DRAM;
                E_training = E_inf + E_back;
                E_training = E_training *minibatch;
                
                E_comm = sum(samp_prob.* power_d_SNR_list) *t_precision;
                
                Energy_consumption_per_iter = I * K * E_training + E_comm * K;
                
                Energy_consumption(j) = Number_of_comm(j)* Energy_consumption_per_iter;
                j = j +1;
            end
        end
    end
end
end
