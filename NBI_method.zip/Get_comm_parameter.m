function [power_d_SNR_list] = Get_comm_parameter(avg_counter, N, length, power, bandwidth, Noise, d, path_loss_exponent)

power_d_SNR_list_temp = zeros(1, N);


for i = linspace(1, avg_counter, avg_counter)
    X_axis = 1 + (length-1).* rand(N,1);
    Y_axis = 1 + (length-1).*rand(N,1);
    distance = sqrt(X_axis.^2 + Y_axis.^2);
    channel_gain = exprnd(1) * distance.^(-path_loss_exponent);
    for j =1:N
        power_d_SNR_list_temp(j) = power_d_SNR_list_temp(j) + power*d/(bandwidth*log2(1 + power * channel_gain(j)/(bandwidth * Noise)));
    end
end

power_d_SNR_list = power_d_SNR_list_temp./avg_counter;
power_d_SNR_list = power_d_SNR_list'; %mAKE it column vector
end