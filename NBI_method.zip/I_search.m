function [I_optimal] = I_search(K, precision, t_precision, SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch)

E = zeros(1, I_max);

E_MAC = A * (precision/n_max)^alpha;
E_M = 2*E_MAC;
E_D = A_d * E_MAC;
E_comp = E_MAC*N_c + 2 * O_c *E_MAC_MAX;
E_weight = E_M * d + E_MAC *N_c *sqrt(precision/(p*n_max));
E_act = 2 * E_M * O_c + E_MAC * N_c * sqrt(precision/(p*n_max));
E_DRAM = A_d * E_MAC_MAX *x_dim + 2 * E_D * max(d*precision + 2*O_c *precision - SRAM, 0);
E_inf = E_comp + E_weight + E_act + E_DRAM;
E_training = E_inf + E_back;
E_training = E_training *minibatch;

E_comm = sum(samp_prob.* power_d_SNR_list) *t_precision;

Psi_one = d*(rho - mu)/2^(2*precision);

 E_C_sum = sum(samp_prob.*E_training);
 E_UL_sum = sum(samp_prob.* power_d_SNR_list)*t_precision;
 A_ = (8*K*SGD_bound^2 + 8*SGD_bound^2) * E_C_sum;
 B_ = (4*K*SGD_bound^2 + 4*SGD_bound^2) * E_UL_sum + (-8*K*SGD_bound^2 +...
     4*d*SGD_bound^2/2^(2*t_precision)) * E_C_sum;
 C_ = -K*E_UL_sum*(variance_term + 4*SGD_bound^2 + 4*L*Noniid - gamma*(beta*mu-1)...
     *(2*epsilon/L - beta*(rho-mu)*d/(2^(2*precision)* (beta*mu - 1)))*1/(beta^2));
 
 I_optimal = (-1/2 * (2/27 * (B_/A_)^3 + C_/A_ ) + ...
     sqrt(1/4 * (2/27 * (B_/A_)^3 + C_/A_)^2 + 1/27 * (B_^2/(3*A_^2))^3 ) )^(1/3) ...
     + (-1/2 * (2/27 * (B_/A_)^3 + C_/A_ ) -...
     sqrt(1/4 * (2/27 * (B_/A_)^3 + C_/A_)^2 + 1/27 * (B_^2/(3*A_^2))^3))^(1/3) - B_/(3*A_);
 I_optimal = min(I_optimal, I_max);
 I_optimal = round(I_optimal);
end