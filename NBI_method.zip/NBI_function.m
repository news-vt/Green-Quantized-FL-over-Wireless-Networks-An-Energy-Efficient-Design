function [Num_glo_iterations, Energy_consumption, Pareto_points, E_min, T_min, E_uto, T_uto] = ...
    NBI_function(N, variance_term, samp_prob, SGD_bound, power_d_SNR_list, ...
    epsilon, L, mu, beta, gamma, d,  rho, Noniid, N_c, NBI_resolution, PENALTY_INCREASE, threshold, p, A, A_d, alpha, O_c, x_dim, SRAM, ...
    E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch)

%x = (I, K, m, n)
Psi_one = @(x) d*(rho - mu)/2^(2*x(4)) + 0*x(1) + 0*x(2) + 0*x(3);
Psi_two = @(x) variance_term + 4*(x(1)-1)^2 * SGD_bound^2 + 4*d*x(1)*SGD_bound^2/(x(2)*2^(2*x(3)))...
    + 4* x(1)^2 * SGD_bound^2/x(2) + 4*L*Noniid + 0*x(4);
T_ = @(x) beta^2 * Psi_two(x)/( x(1) * (beta*mu -1) * (2*epsilon/L - beta*Psi_one(x)/(beta*mu -1))) - gamma/x(1);

E_MAC = @(x) A * (x(4)/n_max)^alpha +x(1) *0 + x(2) *0 +x(3) *0;
E_M = @(x) 2*E_MAC(x);
E_D = @(x) A_d * E_MAC(x);
E_comp = @(x) E_MAC(x)*N_c + 2 * O_c *E_MAC_MAX;
E_weight = @(x) E_M(x) * d + E_MAC(x) *N_c *sqrt(x(4)/(p*n_max));
E_act = @(x) 2 * E_M(x) * O_c + E_MAC(x) * N_c * sqrt(x(4)/(p*n_max));
E_DRAM = @(x) A_d * E_MAC_MAX *x_dim + 2 * E_D(x) * max(d*x(4) + 2*O_c *x(4) -SRAM, 0);
E_inf = @(x) E_comp(x) + E_weight(x) + E_act(x) + E_DRAM(x);
E_training = @(x) (E_inf(x) + E_back) * minibatch;

E_comm = @(x) sum(samp_prob.* power_d_SNR_list) *x(3) + 0*x(1) + 0*x(2) + 0*x(4);

Energy_consumption_per_round = @(x) x(1) * x(2) * E_training(x) + E_comm(x) * x(2);

E_ = @(x) T_(x)* Energy_consumption_per_round(x);

lb = [1, 1, 1, n_min];
ub = [I_max, N, m_max, n_max];
x0 = [1, 1, 1, n_min];
NBI = 0.00;
Resolution = NBI_resolution;
NBI_array =linspace(0, 1, Resolution);
NBI_increase = NBI_array(2) - NBI_array(1);

Num_glo_iterations = zeros(1, length(NBI_array));
Energy_consumption = zeros(1, length(NBI_array));
Pareto_points = zeros(length(NBI_array), 4);

[foo, foo2, foo3, foo4, foo5] =  Energy_opt_function(N,SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch);
x_1 = [foo, foo2, foo3, foo4];
E_min = x_1;
E_uto = E_(E_min);

x_2 = [foo5, N, 32, 32];
T_min = x_2;
T_uto = T_(T_min);

index = 1;

while index < Resolution+1
    
    PENALTY = 10;
    count = 1;
    
    while true
        if count == 1
            fnc = @(x) (T_(x) - T_(T_min))/T_(E_min) + NBI - 1 + PENALTY*(1 - 2*NBI + ...
                (E_(x) - E_(E_min))/E_(T_min) - (T_(x)-T_(T_min))/T_(E_min))^2;
            %             fnc = @(x) (T_(x) - T_(T_min))/T_(E_min)- NBI + PENALTY*(1 - 2*NBI - ...
            %                 (E_(x) - E_(E_min))/E_(T_min) + (T_(x)-T_(T_min))/T_(E_min))^2;
            Present_point = fmincon(fnc, x0, [], [], [] ,[], lb, ub);
        else
            Present_point = Next_point;
        end
        PENALTY = PENALTY_INCREASE * PENALTY;
        fnc = @(x) (T_(x) - T_(T_min))/T_(E_min) + NBI - 1+ PENALTY*(1 - 2*NBI + ...
            (E_(x) - E_(E_min))/E_(T_min) - (T_(x)-T_(T_min))/T_(E_min))^2;
        %         fnc = @(x) (T_(x) - T_(T_min))/T_(E_min)- NBI + PENALTY*(1 - 2*NBI - ...
        %             (E_(x) - E_(E_min))/E_(T_min) + (T_(x)-T_(T_min))/T_(E_min))^2;
        Next_point = fmincon(fnc, Present_point, [], [], [] ,[], lb, ub); %start from the previous optimal, it is much faster
        koo = Present_point - Next_point;
        if sqrt(koo(1)^2 + koo(2)^2 + koo(3)^2 + koo(4)^2) < threshold
            Pareto_optimum = Next_point;
            %             Pareto_optimum = round(Pareto_optimum);
            Num_glo_iterations(index) = T_(Pareto_optimum) ;
            Energy_consumption(index) = E_(Pareto_optimum);
            Pareto_points(index, :) = Pareto_optimum;
            break
        end
        count = count + 1;
    end
    NBI = NBI + NBI_increase;
    index = index + 1;
end


k = 1:1:NBI_resolution-1;
idx_k = Num_glo_iterations(k+1) < Num_glo_iterations(k);
Remover = sum(idx_k);

if Remover == 1
    return
elseif Remover > 1
    Num_glo_iterations(Remover+1:NBI_resolution) = [];
    Energy_consumption(Remover+1:NBI_resolution) = [];
    Pareto_points = Pareto_points(1:Remover, :);
end

end
