function [sampling_prob] = Optimize_sampling_prob(sigma_list)

sigma_inverse =1./sigma_list;
sigma_inverse_square = sigma_inverse.^2;
sigma_square_sum = sum(sigma_inverse_square);
sampling_prob = sigma_inverse_square./sigma_square_sum;
end