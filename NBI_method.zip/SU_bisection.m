function [SU_energy, SU_time, tangential, CONSTANT]  = SU_bisection(NASH_INPUT,CONSTANT_small, CONSTANT_big, Num_glo_iterations, threshold_distant)

distance = zeros(1, length(NASH_INPUT));
CONSTANT = (CONSTANT_small + CONSTANT_big)/2;
NASH_OUTPUT = zeros(1, length(distance));

while true

    para = @(x) -x + CONSTANT; %%parameterized parabola 
    
    for i = 1:length(distance)
        NASH_OUTPUT(i) = para(NASH_INPUT(i)); %the output of the parabola given NASH_INPUT, which is the energy consumption
    end
    
    distance = Num_glo_iterations - NASH_OUTPUT; %distance of y-axis between #of global iterations and NASH_OUTPUT
    
    if min(distance) > threshold_distant %the parabola is below the Pareto boudary and it is not close enough 
        CONSTANT_small = CONSTANT;
        CONSTANT = (CONSTANT_big + CONSTANT)/2;
        
    elseif min(distance) < 0 %the parabola is above the Pareto boundary. The constant is too small 
        CONSTANT_big = CONSTANT;
        CONSTANT = (CONSTANT_small + CONSTANT)/2;
        
    elseif min(distance) < threshold_distant && min(distance) > 0 %the parabola is below the Pareto boundary and it is close enough 
        [foo, tangential] = min(distance);
        tangential = round(tangential);
        SU_energy = NASH_INPUT(tangential);
        SU_time = Num_glo_iterations(tangential);
        break
    end
end

end