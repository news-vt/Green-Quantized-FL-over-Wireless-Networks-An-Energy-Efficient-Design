function [NBS_energy, NBS_time, tangential, CONSTANT, NBS_INPUT, NBS_OUTPUT]...
    = bisection(NASH_INPUT,CONSTANT_small, CONSTANT_big, Num_glo_iterations, Disagree_point_T, Disagree_point_E, threshold_distant)

remove = 1;
for i = 1:length(NASH_INPUT)  
    if NASH_INPUT(i) > Disagree_point_E %Check if there is a point larger than the disagreement
        break
    end
    remove = remove+1;
end
if remove > 1
    NASH_INPUT(remove:length(NASH_INPUT)) = [];
    Num_glo_iterations(remove:length(Num_glo_iterations)) = [];
end

distance = zeros(1, length(NASH_INPUT));
CONSTANT = (CONSTANT_small + CONSTANT_big)/2;
NASH_OUTPUT = zeros(1, length(distance));

while true

    para = @(x) (CONSTANT + Disagree_point_T * x - Disagree_point_T * Disagree_point_E) ...
        /(x - Disagree_point_E); %%parameterized parabola 
    
    for i = 1:length(distance)
        NASH_OUTPUT(i) = para(NASH_INPUT(i)); %the output of the parabola given NASH_INPUT, which is the energy consumption
    end
    
    distance = Num_glo_iterations - NASH_OUTPUT; %distance of y-axis between #of global iterations and NASH_OUTPUT
    
    if min(distance) > threshold_distant %the parabola is below the Pareto boudary and it is not close enough 
        CONSTANT_big = CONSTANT;
        CONSTANT = (CONSTANT_small + CONSTANT)/2;
        
    elseif min(distance) < 0 %the parabola is above the Pareto boundary. The constant is too small 
        CONSTANT_small = CONSTANT;
        CONSTANT = (CONSTANT_big + CONSTANT)/2;
        
    elseif (0 < min(distance)) && (min(distance) <threshold_distant) %the parabola is below the Pareto boundary and it is close enough 
        [foo, tangential] = min(distance);
        tangential = round(tangential);
        NBS_energy = NASH_INPUT(tangential);
        NBS_time = Num_glo_iterations(tangential);
        break
    end
end
NBS_INPUT = NASH_INPUT;
NBS_OUTPUT = NASH_OUTPUT;

end