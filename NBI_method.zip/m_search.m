function [optimal_m] = m_search(K, precision, I, SGD_bound, samp_prob, power_d_SNR_list, epsilon, ...
    L, mu, beta, gamma, rho, Noniid, variance_term, d, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, I_max, m_max, n_min, n_max, minibatch)

E = zeros(1, m_max);


E_MAC = A * (precision/n_max)^alpha;
E_M = 2*E_MAC;
E_D = A_d * E_MAC;
E_comp = E_MAC*N_c + 2 * O_c *E_MAC_MAX;
E_weight = E_M * d + E_MAC *N_c *sqrt(precision/(p*n_max));
E_act = 2 * E_M * O_c + E_MAC * N_c * sqrt(precision/(p*n_max));
E_DRAM = A_d * E_MAC_MAX *x_dim + 2 * E_D * max(d*precision + 2*O_c *precision - SRAM, 0);
E_inf = E_comp + E_weight + E_act + E_DRAM;
E_training = E_inf + E_back;
E_training = E_training *minibatch;

Psi_one = d*(rho - mu)/2^(2*precision);


T_beta =  beta^2 /(I*(beta*mu-1) * (2*epsilon/L - beta*Psi_one/(beta*mu-1)));
M_A = K *((variance_term + 4*(I-1)^2*SGD_bound^2 + 4 * I^2 * SGD_bound^2/K + ...
    4*L *Noniid -gamma/T_beta ))/(4* I * SGD_bound^2 * log(4) *d ) ;
M_C = sum(samp_prob.*power_d_SNR_list);
M_B = (4*d*I*SGD_bound^2/K * M_C - 4 * d * I^2 *SGD_bound^2 * log(4) *  sum(samp_prob.*E_training))...
    /(4 * d *I * SGD_bound^2 * log(4) * M_C);

optimal_m = M_B - 1/(log(4))* lambertw(-1, -M_A *log(4)*exp(M_B*log(4)));
optimal_m = round(optimal_m);
end