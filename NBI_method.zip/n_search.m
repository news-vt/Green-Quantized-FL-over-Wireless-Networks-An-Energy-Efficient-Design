function [E_n_min, n_optimal, E] =  n_search(K, t_precision, I, ...
    samp_prob, power_d_SNR_list, epsilon, L, mu, beta, gamma, d, rho, Noniid, variance_term, ...
    SGD_bound, p, A, A_d, alpha, O_c, N_c, x_dim, SRAM, E_back, E_MAC_MAX, n_min, n_max, minibatch)



n_list = linspace(n_min, n_max, n_max-n_min+1);

E = zeros(1, length(n_list));

j = 1;
 
for precision= n_list
    Psi_one = d*(rho - mu)/2^(2*precision);
    Psi_two = variance_term + 4*(I-1)^2*SGD_bound^2 + 4*d*I*SGD_bound^2/(K*2^(2*t_precision))...
        + 4*I^2*SGD_bound^2/K + 4*L*Noniid;

    T = beta^2 * Psi_two/(I*(beta*mu-1) * (2*epsilon/L - beta*Psi_one/(beta*mu-1))) - gamma/I;
    
    E_MAC = A * (precision/n_max)^alpha;
    E_M = 2*E_MAC;
    E_D = A_d * E_MAC;
    E_comp = E_MAC*N_c + 2 * O_c *E_MAC_MAX;
    E_weight = E_M * d + E_MAC *N_c *sqrt(precision/(p*n_max));
    E_act = 2 * E_M * O_c + E_MAC * N_c * sqrt(precision/(p*n_max));
    E_DRAM = A_d * E_MAC_MAX *x_dim + 2 * E_D * max(d*precision + 2*O_c *precision -SRAM, 0);
    E_inf = E_comp + E_weight + E_act + E_DRAM;
    E_training = E_inf + E_back;
    E_training = E_training *minibatch;

    E_comm = sum(samp_prob.* power_d_SNR_list) *t_precision;
              
    Energy_consumption_per_iter = I * K * E_training + E_comm * K;
                
    E(j) = T* Energy_consumption_per_iter;
    j=j+1;
end



[E_n_min, n_optimal] = min(E);

end

